#include <stdio.h>
#include <stdlib.h>
#define SIZE 5

int item[SIZE], front = -1, rear = -1;

void enqueue()
{
    int value;

    if((front == rear + 1) || (front == 0 && rear == SIZE-1))
    {
        printf("Queue Overflow.");
    }
    else
    {
        printf("Enter any value:");
        scanf("%d", &value);

        if(front == -1)
            front = 0;

        rear = (rear+1)%SIZE;

        item[rear] = value;

        printf("\nInserted value is:%d", value);
    }
}

int dequeue()
{
    int value;

    if(front == -1)
    {
        printf("Queue underflow.");
    }
    else
    {
        value = item[front];

        if(front == rear)
        {
            front = rear = -1;
        }
        else
        {
            front = (front+1)%SIZE;
        }
        printf("\nDeleted element is:%d", value);
        return(value);
    }
}

void display()
{
    int i;

    if(front == -1)
    {
        printf("Queue underflow.");
    }
    else
    {
        printf("\nfront is:%d", front);
        printf("\nValue is:");
        for(i=front; i != rear; i=(i+1)%SIZE)
        {
            printf("%d  ", item[i]);
        }
        printf("%d  ", item[i]);
        printf("\nRear is:%d", rear);
    }
}

int main()
{
    int choice;

    while(1)
    {
        printf("\n\n1. Enqueue().");
        printf("\n2. Dequeue().");
        printf("\n3. Display().");
        printf("\n4. Exit().");
        printf("\n\nEnter your choice:");
        scanf("%d", &choice);

        switch(choice)
        {
        case 1:
            enqueue();
            break;

        case 2:
            dequeue();
            break;

        case 3:
            display();
            break;

        case 4:
            exit(0);

        default:
            printf("Invalid Choice.");
        }
    }

    return 0;
}
