#include <stdio.h>
#include <stdlib.h>

struct node
{
    int info;
    struct node *left;
    struct node *right;
};

struct node *createNode(int value)
{
    struct node *n;

    n = (struct node *)malloc(sizeof(struct node));

    n->info = value;
    n->left = NULL;
    n->right = NULL;

    return(n);
};

struct node *insert(struct node *root, int value)
{
    if(root == NULL)
        return createNode(value);
    else if(value < root->info)
        root->left = insert(root->left, value);
    else if(value > root->info)
        root->right = insert(root->right, value);

    return(root);
};

void inorder(struct node *root)
{
    if(root != NULL)
    {
        inorder(root->left);
        printf("%d  ", root->info);
        inorder(root->right);
    }
}

void preorder(struct node *root)
{
    if(root != NULL)
    {
        printf("%d  ", root->info);
        preorder(root->left);
        preorder(root->right);
    }
}

void postorder(struct node *root)
{
    if(root != NULL)
    {
        postorder(root->left);
        postorder(root->right);
        printf("%d  ", root->info);
    }
}


int main()
{
    struct node *root = NULL;

    root = insert(root, 8);
    insert(root, 3);
    insert(root, 1);
    insert(root, 6);
    insert(root, 7);
    insert(root, 10);
    insert(root, 14);
    insert(root, 16);
    insert(root, 5);

    printf("PreOrder:\n");
    preorder(root);
    printf("\nInOrder:\n");
    inorder(root);
    printf("\nPostOrder:\n");
    postorder(root);

    return 0;
}
