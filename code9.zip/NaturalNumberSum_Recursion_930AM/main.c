#include <stdio.h>
#include <stdlib.h>

/*

    Recursion:

    function calling itself is called recursion.

    base condition

*/

int main()
{
    int k;

    k = func(3);

    printf("%d", k); //6

    return 0;
}


int func(int a)//3
{
    int s;

    if(a == 1) //base condition
        return (a);

    s = a + func(a-1);
    return (s);
}
