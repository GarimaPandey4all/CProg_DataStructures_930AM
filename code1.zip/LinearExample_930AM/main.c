#include <stdio.h>
#include <stdlib.h>

//67 78 89 23 10 20 30 60

//search = 10

int main()
{
    int array[30], search, i, n;

    printf("Enter any number of elements:");
    scanf("%d", &n);

    printf("Enter %d Integers:\n", n);
    for(i=0; i<n; i++)
    {
        scanf("%d", &array[i]);
    }

    printf("Enter any number to be search:");
    scanf("%d", &search);

    for(i=0; i<n; i++)
    {
        if(array[i] == search)
        {
            printf("%d number is found at location %d.", search, i+1);
            break;
        }
    }

    if(i == n)
    {
        printf("%d number is not found.", search);
    }

    return 0;
}
