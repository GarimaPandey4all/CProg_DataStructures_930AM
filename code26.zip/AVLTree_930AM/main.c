#include <stdio.h>
#include <stdlib.h>

struct Node
{
    int info;
    struct Node *left;
    struct Node *right;
    int height;
};

struct Node *createNode(int info)
{
    struct Node *n;

    n = (struct Node *)malloc(sizeof(struct Node));

    n->info = info;
    n->left = NULL;
    n->right = NULL;
    n->height = 1;

    return (n);
};

int height(struct Node *n)
{
    if(n == NULL)
        return 0;
    return n->height;
}

int max(int a, int b)
{
    return (a>b)?a:b;
}

int getBalance(struct Node *n)
{
    if(n == NULL)
        return 0;
    return height(n->left) - height(n->right);
}

struct Node *rightRotate(struct Node *n)
{
    struct Node *m = n->left;
    struct Node *z = m->right;

    //rotation
    m->right = n;
    n->left = z;

    n->height = max(height(n->left), height(n->right)) + 1;
    m->height = max(height(m->left), height(m->right)) + 1;

    return (m);
};

struct Node *leftRotate(struct Node *m)
{
    struct Node *n= m->right;
    struct Node *z = n->left;

    //rotation
    n->left = m;
    m->right = z;

    m->height = max(height(m->left), height(m->right)) + 1;
    n->height = max(height(n->left), height(n->right)) + 1;

    return (n);
};

struct Node *insert(struct Node *node, int info)
{
    if(node == NULL)
        return (createNode(info));

    if(info < node->info)
        node->left = insert(node->left, info);
    else if(info > node->info)
        node->right = insert(node->right, info);
    else
        return node;

    node->height = 1 + max(height(node->left), height(node->right));

    int balance = getBalance(node);

    //left-left rotation
    if(balance > 1 && info < node->left->info)
        return rightRotate(node);

    //right-right rotation
    if(balance < -1 && info > node->right->info)
        return leftRotate(node);

    //left-right rotation
    if(balance > 1 && info > node->left->info)
    {
        node->left = leftRotate(node->left);
        return rightRotate(node);
    }

    //right-left rotation
     if(balance < -1 && info < node->right->info)
    {
        node->left = rightRotate(node->right);
        return leftRotate(node);
    }
    return node;
};

struct Node *minvaluefind(struct Node *node)
{
    struct Node *t = node;

    while(t->left != NULL)
        t = t->left;

    return t;
};

struct Node *delete(struct Node *node, int info)
{
    if(node == NULL)
        return node;

    if(info < node->info)
        node->left = delete(node->left, info);
    else if(info > node->info)
        node->right = delete(node->right, info);
    else
    {
        if(node->left == NULL || node->right == NULL)
        {
            struct Node *temp;

            temp = node->left ? node->left : node->right;

            if(temp == NULL)
            {
                temp = node;
                node = NULL;
            }
            else
            {
                *node = *temp;
            }

            free(temp);
        }
        else
        {
            struct Node *temp1;

            temp1 = minvaluefind(node->right); //successor

            node->info = temp1->info;

            node->right = delete(node->right, temp1->info);
        }
    }

    if(node == NULL)
        return node;

    node->height = 1 + max(height(node->left), height(node->right));

    int balance = getBalance(node);

    //left-left rotation
    if(balance > 1 && getBalance(node->left) >= 0)
        return rightRotate(node);

    //right-right rotation
    if(balance < -1 && getBalance(node->right) <= 0)
        return leftRotate(node);

    //left-right rotation
    if(balance > 1 && getBalance(node->left) < 0)
    {
        node->left = leftRotate(node->left);
        return rightRotate(node);
    }

    //right-left rotation
     if(balance < -1 && getBalance(node->right) > 0)
    {
        node->right = rightRotate(node->right);
        return leftRotate(node);
    }
    return node;
};

void preOrder(struct Node *root)
{
    if(root != NULL)
    {
        printf("%d  ", root->info);
        preOrder(root->left);
        preOrder(root->right);
    }
}

int main()
{
    struct Node *root = NULL;

    root = insert(root, 33);
    root = insert(root, 20);
    root = insert(root, 10);
    root = insert(root, 40);
    root = insert(root, 25);

    printf("Preorder Traversal of the AVL Tree:\n");
    preOrder(root);

    root = delete(root, 10);

    printf("\nPreorder Traversal of the AVL Tree:\n");
    preOrder(root);

    return 0;
}
