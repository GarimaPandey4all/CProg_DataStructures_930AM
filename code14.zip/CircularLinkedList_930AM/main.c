#include <stdio.h>
#include <stdlib.h>

struct node
{
    int info;
    struct node *link;
};

struct node *last = NULL;

//Create a node
struct node *createNode()
{
    struct node *n;

    n = (struct node *)malloc(sizeof(struct node));

    return(n);
};

//Insert to Empty List
void insertToEmpty()
{
    struct node *temp;

    if(last == NULL)
    {
        temp = createNode();

        printf("Enter a number:");
        scanf("%d", &temp->info);

        last = temp;
        last->link = last;
    }
    else
        printf("List is not Empty.");
}

//Insert at Start in a list
void insertAtStart()
{
    struct node *temp;

    if(last == NULL)
        printf("List is Empty.");
    else
    {
        temp = createNode();

        printf("Enter a number:");
        scanf("%d", &temp->info);

        temp->link = last->link;
        last->link = temp;
    }
}

//Insert at end
void insertAtEnd()
{
    struct node *temp;

    if(last == NULL)
        printf("List is Empty.");
    else
    {
        temp = createNode();

        printf("Enter a number:");
        scanf("%d", &temp->info);

        temp->link = last->link;

        last->link = temp;

        last = temp;
    }
}

//InsertAfterNode
void insertAfterNode()
{
    struct node *temp, *ptr;
    int search;

    if(last == NULL)
        printf("List is Empty.");

    printf("Enter any value to be search:");
    scanf("%d", &search);

    ptr = last->link;

    do
    {
        if(ptr->info == search)
        {
            temp = createNode();

            printf("Enter a number:");
            scanf("%d", &temp->info);

            temp->link = ptr->link;
            ptr->link = temp;

            if(ptr == last)
                last = temp;
        }
        ptr = ptr->link;
    }while(ptr != last->link);

    printf("%d is not found in a list.", search);
}

//Delete from a list
void deleteNode()
{
    struct node *p, *t;
    int search;

    if(last == NULL)
    {
        printf("List is Empty.");
    }
    printf("Enter any value to be search:");
    scanf("%d", &search);

    //If only one node exist in a list
    if(last == last->link && last->info == search)
    {
        t = last;
        last = NULL;
        free(t);
    }

    //If only two nodes exist in a list
    if(last->link->info == search)
    {
        t = last->link;
        last->link = t->link;
        free(t);
    }

//If we have more than two nodes in a list

    p = last->link;

    while(p->link != last)
    {
        if(p->link->info == search)
        {
            t = p->link;
            p->link = t->link;
            free(t);
        }
        p = p->link;
    }

//If we have more than two nodes in a list but we want to delete last node from a list

    if(last->info == search)
    {
        t = last;
        p->link = last->link;
        last = p;
        free(t);
    }

    printf("%d is not found in a list.");

}

int main()
{

    return 0;
}
