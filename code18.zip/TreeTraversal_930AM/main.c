#include <stdio.h>
#include <stdlib.h>

struct node
{
    int info;
    struct node *left;
    struct node *right;
};

struct node *createNode(value)
{
    struct node *n;

    n = (struct node *)malloc(sizeof(struct node));

    n->info = value;
    n->left = NULL;
    n->right = NULL;

    return(n);
};

void inorder(struct node *root)
{
    if(root != NULL)
    {
        inorder(root->left);
        printf("%d  ", root->info);
        inorder(root->right);
    }
}

void preorder(struct node *root)
{
    if(root != NULL)
    {
        printf("%d  ", root->info);
        preorder(root->left);
        preorder(root->right);
    }
}

void postorder(struct node *root)
{
    if(root != NULL)
    {
        postorder(root->left);
        postorder(root->right);
        printf("%d  ", root->info);
    }
}

struct node *insertleft(struct node *root, int value)
{
    root->left = createNode(value);
    return root->left;
};

struct node *insertright(struct node *root, int value)
{
    root->right = createNode(value);
    return root->right;
};

int main()
{
    struct node *root = createNode(1);

    insertleft(root, 12);
    insertright(root, 9);

    insertleft(root->left, 5);
    insertright(root->left, 6);

    printf("Inorder Traversal:\n");
    inorder(root);

    printf("\nPreorder Traversal:\n");
    preorder(root);


    printf("\nPostorder Traversal:\n");
    postorder(root);

    return 0;
}
