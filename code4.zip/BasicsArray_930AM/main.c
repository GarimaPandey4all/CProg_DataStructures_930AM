#include <stdio.h>
#include <stdlib.h>

int main()
{
    int array[5]; //Array Declaration

    int array[5] = {10, 20, 30, 40, 50};
    //Traditional Way of
    //initialization of an array

    int array[] = {10, 20, 30, 40, 50, 60, 70, 80, 90};
    //compile time initialization

    int array[][3] = {{2, 3, 4},
                      {3, 4, 5},
                      {4, 5, 6}};

    //Jagged Array:

    /*
        1. Static Jagged Array

        2. Dynamic Jagged Array
    */

    return 0;
}
