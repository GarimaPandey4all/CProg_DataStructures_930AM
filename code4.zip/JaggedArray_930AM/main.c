#include <stdio.h>
#include <stdlib.h>

int main()
{
    int array[] = {10, 20, 30, 40, 50, 60, 70, 80, 90};
    int i;

    for(i=0; i<9; i++)
    {
        printf("%d  ", array[i]);
    }

    return 0;
}
