#include <stdio.h>
#include <stdlib.h>

int main()
{
    int array[2][2][2], i, j, k;

    printf("Insert values in 3D Array:");
    for(i=0; i<2; i++)
    {
        for(j=0; j<2; j++)
        {
            for(k=0; k<2; k++)
            {
                scanf("%d", &array[i][j][k]);
            }
        }
    }

    for(i=0; i<2; i++)
    {
        for(j=0; j<2; j++)
        {
            for(k=0; k<2; k++)
            {
                printf("%d  ", array[i][j][k]);
            }
        }
    }

    return 0;
}
