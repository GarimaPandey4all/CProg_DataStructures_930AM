#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a[5]; //array declare

    int a[5] = {10, 20, 30, 40, 50};

    //decalare  and initialize// Traditional way of initialization

    int a[] = {10, 20, 30, 40, 50, 60, 70, 80, 90};

    //compile time initialization

    int array[2][3] = {{2, 5, 6},
                       {7, 8, 9}}

    int array[][3] = {{2, 5, 6}, {7, 8, 9}};

    //compile time initialization

    int array[2][2][2] = {{2, 3}, {4, 5} , {5, 8}, {7, 8}};

    int array[2][3][4];

    return 0;
}
