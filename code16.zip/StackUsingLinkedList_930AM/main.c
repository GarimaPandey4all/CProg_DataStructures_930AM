#include <stdio.h>
#include <stdlib.h>

struct node
{
    int info;
    struct node *link;
};

struct node *Top = NULL;

struct node *createNode()
{
    struct node *n;

    n = (struct node *)malloc(sizeof(struct node));

    return(n);
};

void push()
{
    struct node *temp;

    temp = createNode();

    printf("Enter a number:");
    scanf("%d", &temp->info);

    temp->link = Top;

    Top = temp;
}

void pop()
{
    struct node *temp;

    if(Top == NULL)
        printf("Stack Underflow.");
    else
    {
        temp = Top;

        Top = Top->link;

        free(temp);
    }
}

void display()
{
    struct node *T;

    if(Top == NULL)
        printf("Stack Underflow.");
    else
    {
        T = Top;

        while(T != NULL)
        {
            printf("%d  ", T->info);
            T = T->link;
        }
    }
}


int main()
{
    int choice;

    while(1)
    {
        printf("\n\n1. Push().");
        printf("\n2. Pop().");
        printf("\n3. Display().");
        printf("\n4. Exit.");
        printf("\n\nEnter your choice:");
        scanf("%d", &choice);

        switch(choice)
        {
        case 1:
            push();
            break;

        case 2:
            pop();
            break;

        case 3:
            display();
            break;

        case 4:
            exit(0);

        default:
            printf("Invalid Choice.");
        }
    }
    return 0;
}
