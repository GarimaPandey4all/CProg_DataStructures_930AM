#include <stdio.h>
#include <stdlib.h>

int main()
{
    int matrix[5][5], i, j, rows, columns;

    printf("Enter any number of rows:");
    scanf("%d", &rows);

    printf("Enter any number of columns:");
    scanf("%d", &columns);

    printf("Enter %d Values:\n", rows*columns);
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            scanf("%d", &matrix[i][j]);
        }
    }

    printf("Values in Matrix:\n");
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            printf("%d\t", matrix[i][j]);
        }
        printf("\n");
    }

    //Principal diagonal matrix

    printf("Principal diagonal matrix is:\n");
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            if(i == j)
            {
                printf("%d  ", matrix[i][j]);
            }
        }
    }

    return 0;
}
