#include <stdio.h>
#include <stdlib.h>

int main()
{
    int marks[5], i, sum=0, percentage;

    printf("Enter your marks:");
    for(i=0; i<5; i++)
        scanf("%d", &marks[i]);

    for(i=0; i<5; i++)
        sum += marks[i]; //sum = sum + marks[i];

    printf("Total marks is:%d\n", sum);

    percentage = sum/5;

    printf("Percenatge is:%d", percentage);

    return 0;
}
