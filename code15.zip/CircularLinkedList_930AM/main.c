#include <stdio.h>
#include <stdlib.h>

struct node
{
    int info;
    struct node *link;
};

struct node *last = NULL;

//Create a node
struct node *createNode()
{
    struct node *n;

    n = (struct node *)malloc(sizeof(struct node));

    return(n);
};

//Insert to Empty List
void insertToEmpty()
{
    struct node *temp;

    if(last == NULL)
    {
        temp = createNode();

        printf("Enter a number:");
        scanf("%d", &temp->info);

        last = temp;
        last->link = last;
    }
    else
        printf("List is not Empty.");
}

//Insert at Start in a list
void insertAtStart()
{
    struct node *temp;

    if(last == NULL)
        printf("List is Empty.");
    else
    {
        temp = createNode();

        printf("Enter a number:");
        scanf("%d", &temp->info);

        temp->link = last->link;
        last->link = temp;
    }
}

//Insert at end
void insertAtEnd()
{
    struct node *temp;

    if(last == NULL)
        printf("List is Empty.");
    else
    {
        temp = createNode();

        printf("Enter a number:");
        scanf("%d", &temp->info);

        temp->link = last->link;

        last->link = temp;

        last = temp;
    }
}

//InsertAfterNode
int insertAfterNode()
{
    struct node *temp, *ptr;
    int search;

    if(last == NULL)
    {
        printf("List is Empty.");
        return(0);
    }

    printf("Enter any value to be search:");
    scanf("%d", &search);

    ptr = last->link;

    do
    {
        if(ptr->info == search)
        {
            temp = createNode();

            printf("Enter a number:");
            scanf("%d", &temp->info);

            temp->link = ptr->link;
            ptr->link = temp;

            if(ptr == last)
                last = temp;

            return(1);
        }
        ptr = ptr->link;
    }while(ptr != last->link);

    printf("%d is not found in a list.", search);
    return(0);
}

//Delete from a list
int deleteNode()
{
    struct node *p, *t;
    int search;

    if(last == NULL)
    {
        printf("List is Empty.");
        return(0);
    }
    printf("Enter any value to be search:");
    scanf("%d", &search);

    //If only one node exist in a list
    if(last == last->link && last->info == search)
    {
        t = last;
        last = NULL;
        free(t);
        return(1);
    }

    //If only two nodes exist in a list
    if(last->link->info == search)
    {
        t = last->link;
        last->link = t->link;
        free(t);
        return(1);
    }

//If we have more than two nodes in a list

    p = last->link;

    while(p->link != last)
    {
        if(p->link->info == search)
        {
            t = p->link;
            p->link = t->link;
            free(t);
            return(1);
        }
        p = p->link;
    }

//If we have more than two nodes in a list but we want to delete last node from a list

    if(last->info == search)
    {
        t = last;
        p->link = last->link;
        last = p;
        free(t);
        return(1);
    }

    printf("%d is not found in a list.");
    return(0);

}

//Traverse the list
void viewList()
{
    struct node *T;

    if(last == NULL)
    {
        printf("List is Empty.");
    }
    else
    {
        T = last->link;
        do
        {
            printf("%d  ", T->info);
            T = T->link;
        }while(T != last->link);
    }
}

int main()
{
    int choice;

    while(1)
    {
        printf("\n\n1. Insert in an Empty list.");
        printf("\n2. Insert at start position in a list.");
        printf("\n3. Insert at end position in a list.");
        printf("\n4. Insert after a particular node in a list.");
        printf("\n5. Delete node from a list.");
        printf("\n6. Traverse the list.");
        printf("\n7. Exit.");
        printf("\n\nEnter your choice:");
        scanf("%d", &choice);

        switch(choice)
        {
        case 1:
            insertToEmpty();
            break;

        case 2:
            insertAtStart();
            break;

        case 3:
            insertAtEnd();
            break;

        case 4:
            insertAfterNode();
            break;

        case 5:
            deleteNode();
            break;

        case 6:
            viewList();
            break;

        case 7:
            exit(0);

        default:
            printf("Invalid Choice.");
        }
    }
    return 0;
}
