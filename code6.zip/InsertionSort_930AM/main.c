#include <stdio.h>
#include <stdlib.h>

/*
    10, 3, 7, 5, 2
    3 ,10, 7, 5, 2
    3 , ? 10, 5, 2
    3, 7, 10, 5, 2
    3, 7,  ?, 10,2
    3, ?, 7, 10, 2
    3, 5, 7, 10, 2
    3, 5, 7, ?, 10
    3, 5, ?, 7, 10
    3, ?, 5, 7, 10
    ?, 3, 5, 7, 10
    2, 3, 5, 7, 10

*/



int main()
{
    int array[20], i, j, n, temp;

    printf("Enter number of elements:");
    scanf("%d", &n);

    printf("Enter %d values in an array:", n);
    for(i=0; i<n; i++)
    {
        scanf("%d", &array[i]);
    }

    printf("\nValues in an Array are:\n");
    for(i=0; i<n; i++)
    {
        printf("%d  ", array[i]);
    }

    //Logic for Insertion Sort

    for(i=1; i<n; i++)
    {
        temp = array[i];
        j = i-1;

        while(j>=0 && array[j] > temp)
        {
            array[j+1] = array[j];
            j = j-1; //j=0, -1,
        }
        array[j+1] = temp;
    }

    printf("\nInsertion Sorted List is:\n");
    for(i=0; i<n; i++){
        printf("%d  ", array[i]);
    }

    return 0;
}
