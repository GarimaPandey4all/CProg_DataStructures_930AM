#include <stdio.h>
#include <stdlib.h>

/*
    Leaders in an Array:

    15, 18, 3, 6, 2

    maxElement = 0, 2, 6, 18

    Leaders are: 2, 6, 18

    17, 20, 15, 8, 2, 9

    Leaders are: 9, 15, 20

    Time Complexity is O(n);
*/

int main()
{
    int array[20], i, n, maxElement = 0;

    printf("Enter number of elements:");
    scanf("%d", &n);

    printf("Enter %d values in an Array:", n);
    for(i=0; i<n; i++)
    {
        scanf("%d", &array[i]);
    }


    printf("\nValues in an Array are:\n");
    for(i=0; i<n; i++)
    {
        printf("%d  ", array[i]);
    }

    //Logic to find leaders in an array

    printf("\nLeaders in an Array are:\n");
    for(i=n-1; i>=0; i--)
    {
        if(array[i] > maxElement)
        {
            printf("%d  ", array[i]);
            maxElement = array[i];
        }
    }

    return 0;
}
