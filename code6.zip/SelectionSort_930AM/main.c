#include <stdio.h>
#include <stdlib.h>

/*

    10, 3, 1, 2, 5, 6
    1, 3, 10, 2, 5, 6
    1, 2, 10, 3, 5, 6
    1, 2, 3, 10, 5, 6
    1, 2, 3, 5, 10, 6
    1, 2, 3, 5, 6, 10

*/


int main()
{

    int array[20], n, i, j, temp, min;

    printf("Enter number of elements:");
    scanf("%d", &n);

    printf("Enter %d Values in an Array:", n);
    for(i=0; i<n; i++)
    {
        scanf("%d", &array[i]);
    }

    printf("\nValues in an array are:\n");
    for(i=0; i<n; i++)
    {
        printf("%d  ", array[i]);
    }

    //Logic for Selection Sort

    for(i=0; i<n-1; i++)
    {
        min = i;
        for(j=i+1; j<n; j++)
        {
            if(array[j] < array[min])
            {
               min = j;
            }
        }
        //Swapping
        temp = array[i];
        array[i] = array[min];
        array[min] = temp;
    }

    printf("\nSelection Sorted List is:\n");
    for(i=0; i<n; i++)
    {
        printf("%d  ", array[i]);
    }

    return 0;
}
