#include <stdio.h>
#include <stdlib.h>

void quickSort(int number[10], int first, int last)
{
    int i, j, pivot, temp;

    if(first < last)
    {
        pivot = first;
        i = first;
        j = last;

        while(i < j)
        {
            while(number[i] <= number[pivot] && i < last)
            {
                i++;
            }

            while(number[j] > number[pivot])
            {
                j--;
            }

            if(i < j)
            {
                temp = number[i];
                number[i] = number[j];
                number[j] = temp;
            }
        }

        //swapping the pivot number
        temp = number[pivot];
        number[pivot] = number[j];
        number[j] = temp;

        //recursively sort both the arrays
        quickSort(number, first, j-1); //left sub-array sort
        quickSort(number, j+1, last); //right sub-array sort

    }
}


int main()
{
    int i, n, number[10];

    printf("Enter number of elements:");
    scanf("%d", &n);

    printf("Enter %d Integers:", n);
    for(i=0; i<n; i++)
    {
        scanf("%d", &number[i]);
    }

    quickSort(number, 0, n-1); //function calling

    printf("Sorted Array is:\n");
    for(i=0; i<n; i++)
        printf("%d  ", number[i]);

    return 0;
}
