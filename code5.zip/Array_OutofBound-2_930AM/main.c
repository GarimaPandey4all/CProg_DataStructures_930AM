#include <stdio.h>
#include <stdlib.h>

int main()
{
    int array[] = {10, 20, 30, 40, 50};

    printf("Value at array[4]:%d\n", array[4]);

    //Array[10] is out of bound error
    printf("Value at array[10]:%d\n", array[10]);

    array[10] = 70;

    //runtime error
    printf("Value at array[10]:%d", array[10]);

    return 0;
}
