#include <stdio.h>
#include <stdlib.h>

/*
    Binary Search:
    0  1  2  3   4   5  6    7
    3, 6, 8, 9, 13, 15, 19, 25

    first = 0
    last  = 7 (n-1)

    search = 15;

    middle = (first+last)/2 = 3

    3rd = 9

    middle < search

    first = middle + 1 = 3 + 1 = 4

    middle = (first+last)/2 = (4 + 7)/2 = 5

    middle = 5

    middle == search = true

    found search element

    case : search = 6

    middle = 3

    last = middle - 1;

    last = 2

    middle = (0 + 2)/2 = 1

    middle == search

*/

int main()
{
    int array[20], i, n, first, last, middle, search;

    printf("Enter number of elements:");
    scanf("%d", &n);

    printf("Enter %d Integers:", n);
    for(i=0; i<n; i++)
    {
        scanf("%d", &array[i]);
    }

    printf("Values in Array are:\n");
    for(i=0; i<n; i++)
    {
        printf("%d\t", array[i]);
    }

    printf("\nEnter any number that you want to be search:");
    scanf("%d", &search);

    first = 0;
    last = n-1;

    middle = (first + last)/2;

    while(first <= last)
    {
        if(array[middle] < search)
        {
            first = middle + 1;
        }
        else if(array[middle] == search)
        {
            printf("\n%d element found at location %d.\n", search, (middle + 1));
            break;
        }
        else
        {
            last = middle - 1;
        }

        middle = (first + last)/2;
    }
    return 0;
}
