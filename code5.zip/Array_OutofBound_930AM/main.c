#include <stdio.h>
#include <stdlib.h>

int main()
{
    int array[5] = {10, 20, 30, 40, 50, 60};
    int i;

    array[0] = 10;
    array[1] = 20;
    array[2] = 30;
    array[3] = 40;
    array[4] = 50;
    array[10] = 60;

    //array[10] = 100;

    printf("Value at array[10]: %d", array[10]);

//    printf("Values in array are:\n");
//    for(i=0; i<6; i++)
//        printf("%d  ", array[i]);

    return 0;
}
